import tkinter as tk
from tkinter import messagebox
import sqlite3


def connect_db():
    conn = sqlite3.connect("movies.db")
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS movies (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        title TEXT,
                        director TEXT,
                        year INTEGER,
                        genre TEXT)''')
    conn.commit()
    return conn, cursor


def add_movie():
    title = entry_title.get()
    director = entry_director.get()
    year = entry_year.get()
    genre = entry_genre.get()
    
    if title and director and year and genre:
        try:
            conn, cursor = connect_db()
            cursor.execute("INSERT INTO movies (title, director, year, genre) VALUES (?, ?, ?, ?)",
                           (title, director, int(year), genre))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Movie added successfully!")
            clear_entries()
            show_movies()
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    else:
        messagebox.showwarning("Input Error", "Please fill all fields.")


def update_movie():
    movie_id = entry_movie_id.get()
    title = entry_title.get()
    director = entry_director.get()
    year = entry_year.get()
    genre = entry_genre.get()
    
    if movie_id and title and director and year and genre:
        try:
            conn, cursor = connect_db()
            cursor.execute("UPDATE movies SET title = ?, director = ?, year = ?, genre = ? WHERE id = ?",
                           (title, director, int(year), genre, int(movie_id)))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Movie updated successfully!")
            clear_entries()
            show_movies()
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    else:
        messagebox.showwarning("Input Error", "Please fill all fields.")


def delete_movie():
    movie_id = entry_movie_id.get()
    
    if movie_id:
        try:
            conn, cursor = connect_db()
            cursor.execute("DELETE FROM movies WHERE id = ?", (int(movie_id),))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Movie deleted successfully!")
            clear_entries()
            show_movies()
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    else:
        messagebox.showwarning("Input Error", "Please enter a movie ID to delete.")


def search_movie():
    title = entry_title.get()
    
    if title:
        try:
            conn, cursor = connect_db()
            cursor.execute("SELECT * FROM movies WHERE title LIKE ?", ('%' + title + '%',))
            movies = cursor.fetchall()
            conn.close()
            
            if movies:
                listbox_movies.delete(0, tk.END)
                for movie in movies:
                    listbox_movies.insert(tk.END, f"ID: {movie[0]}, Title: {movie[1]}, Director: {movie[2]}, Year: {movie[3]}, Genre: {movie[4]}")
            else:
                messagebox.showinfo("No Results", "No movies found with that title.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    else:
        messagebox.showwarning("Input Error", "Please enter a title to search.")


def show_movies():
    try:
        conn, cursor = connect_db()
        cursor.execute("SELECT * FROM movies")
        movies = cursor.fetchall()
        conn.close()
        
        listbox_movies.delete(0, tk.END)
        for movie in movies:
            listbox_movies.insert(tk.END, f"ID: {movie[0]}, Title: {movie[1]}, Director: {movie[2]}, Year: {movie[3]}, Genre: {movie[4]}")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")


def clear_entries():
    entry_movie_id.delete(0, tk.END)
    entry_title.delete(0, tk.END)
    entry_director.delete(0, tk.END)
    entry_year.delete(0, tk.END)
    entry_genre.delete(0, tk.END)


root = tk.Tk()
root.title("Movie Database")
root.geometry("600x500")


tk.Label(root, text="Movie ID (for update/delete):").pack(pady=5)
entry_movie_id = tk.Entry(root)
entry_movie_id.pack(pady=5)

tk.Label(root, text="Movie Title:").pack(pady=5)
entry_title = tk.Entry(root)
entry_title.pack(pady=5)

tk.Label(root, text="Director:").pack(pady=5)
entry_director = tk.Entry(root)
entry_director.pack(pady=5)

tk.Label(root, text="Year:").pack(pady=5)
entry_year = tk.Entry(root)
entry_year.pack(pady=5)

tk.Label(root, text="Genre:").pack(pady=5)
entry_genre = tk.Entry(root)
entry_genre.pack(pady=5)


tk.Button(root, text="Add Movie", command=add_movie).pack(pady=5)
tk.Button(root, text="Update Movie", command=update_movie).pack(pady=5)
tk.Button(root, text="Delete Movie", command=delete_movie).pack(pady=5)
tk.Button(root, text="Search Movie", command=search_movie).pack(pady=5)


listbox_movies = tk.Listbox(root, width=80, height=10)
listbox_movies.pack(pady=10)


show_movies()


root.mainloop()
