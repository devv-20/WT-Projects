import socket
import threading


questions = [
    {"question": "What is the capital of India?", "answer": "new delhi"},
    {"question": "What is 5 + 7?", "answer": "12"},
    {"question": "Who wrote 'Godhan'?", "answer": "premchand"},
    {"question": "What is the boiling point of water (in Celsius)?", "answer": "100"},
]


clients = []
scores = {}


def handle_client(client_socket, client_address):
    print(f"[INFO] Client {client_address} connected.")
    client_socket.send("Welcome to the Quiz Game!\n".encode())

    
    scores[client_address] = 0

    
    for i, q in enumerate(questions):
        question = f"Question {i + 1}: {q['question']}\n"
        client_socket.send(question.encode())
        
       
        try:
            answer = client_socket.recv(1024).decode().strip().lower()
            if answer == q['answer']:
                scores[client_address] += 1
                client_socket.send("Correct!\n".encode())
            else:
                client_socket.send(f"Wrong! The correct answer is: {q['answer']}\n".encode())
        except:
            print(f"[ERROR] Failed to receive answer from {client_address}")
            break

    
    client_socket.send(f"Your final score is: {scores[client_address]}/{len(questions)}\n".encode())
    client_socket.send("Thank you for playing!\n".encode())
    print(f"[INFO] Client {client_address} scored {scores[client_address]}/{len(questions)}")
    client_socket.close()


def start_server(host='127.0.0.1', port=8080):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"[INFO] Server started on {host}:{port}")

    while True:
        client_socket, client_address = server_socket.accept()
        clients.append(client_address)
        client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
        client_thread.start()

if __name__ == "__main__":
    start_server()
