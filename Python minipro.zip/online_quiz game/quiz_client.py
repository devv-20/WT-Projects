import socket

def start_client(host='127.0.0.1', port=8080):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    while True:
        try:
            
            message = client_socket.recv(1024).decode()
            if not message:
                break
            print(message, end="")

           
            if "Question" in message:
                answer = input("Your Answer: ").strip()
                client_socket.send(answer.encode())
        except:
            print("[ERROR] Connection lost.")
            break

    client_socket.close()

if __name__ == "__main__":
    start_client()

